<footer class="main-footer d-flex p-2 px-3 bg-white border-top">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="https://app.wapido.com">Ir a Wapido</a>
      </li>
    </ul>
    <span class="copyright ml-auto my-auto mr-2">Copyright © 2020
      <a href="https://app.wapido.com" rel="nofollow">
        <img class="d-inline-block align-top mr-1" style="max-width: 25px; width: 25%;" src="{{ asset('img/wapido_logo2.png') }}">
      </a>
    </span>
  </footer>
